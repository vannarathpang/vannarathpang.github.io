NSFW Sound Pack - Release v03.00

Credits: A big thanks to both Ashal and Leito for letting me sounds from their mods.

Summary: This is a pack of sounds for FO4 that can be used as a resource by other mods. Since I'm planning to release several mods that use these sounds, it doesn't make sense to package them separately with each mod (and doing so would probably cause NMM or whatever manager people use to shit itself over all the conflicts). Instead, I will maintain a this as a single pack that has the sounds for all of my mods. I will not change the file pathways of existing sounds, so other modders are welcome to use this pack as a resource for their own mods. 

Conditions: 

- Do not post these files to sites outside of LL. Basically, don't be that person who puts this up on Nexus or Bethesda.net...

- You cannot charge for mods that contain these sounds. 
  

Requirements:

None. But these files won't do anything unless another mod references them. 


Installation:

Copy the files in the Data folder to your data folder. Be sure to maintain the file structure, otherwise the sounds won't work in game. 